package Interfaces;

public interface PaymentStrategy {
    boolean processPayment();
}
